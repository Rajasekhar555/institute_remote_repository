from django.apps import AppConfig


class SignuploginappConfig(AppConfig):
    name = 'signuploginApp'
