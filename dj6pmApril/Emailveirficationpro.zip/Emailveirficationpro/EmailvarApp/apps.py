from django.apps import AppConfig


class EmailvarappConfig(AppConfig):
    name = 'EmailvarApp'
