from django.apps import AppConfig


class MongoappConfig(AppConfig):
    name = 'MongoApp'
